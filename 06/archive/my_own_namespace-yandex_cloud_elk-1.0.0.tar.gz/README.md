
# Ansible Collection - my_own_namespace.yandex_cloud_elk

My collection

## Included Roles
* `create_file` - Создание файла с кастомным текстом

## Included Modules
* `my_own_module` - Кастомный модуль для создания файла с текстом

## Usage Example

```yaml
---
- hosts: localhost
  gather_facts: false
  collections:
    - my_own_namespace.yandex_cloud_elk
  roles:
    - create_file
```