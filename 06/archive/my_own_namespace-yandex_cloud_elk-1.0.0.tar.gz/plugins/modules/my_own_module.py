#!/usr/bin/python
# Copyright: (c) 2018, Terry Jones <terry.jones@example.org>
# GNU General Public License v3.0+ (see COPYING or https://gnu.org)

from __future__ import (absolute_import, division, print_function)
import os
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_test
short_description: This is my test module
# If this is part of a collection, you need to use semantic versioning,
# i.e. the version is of the form "2.5.0" and not "2.4".
version_added: "1.0.0"
description: This is my longer description explaining my test module.
options:
  path:
    description: This is the path to the file to be created.
    required: true
    type: str
  content:
    description: This is the content to be written into the file.
    required: true
    type: str
# Specify this value according to your collection
# in format of namespace.collection.doc_fragment_name
extends_documentation_fragment:
  - my_namespace.my_collection.my_doc_fragment_name
author:
  - Your Name (@yourGitHubHandle)
'''

EXAMPLES = r'''
# Pass in a path and content
- name: Test creating a file
  my_namespace.my_collection.my_test:
    path: /tmp/testfile.txt
    content: hello world
'''

RETURN = r'''
path:
  description: The target path where the file was managed.
  type: str
  returned: always
  sample: '/tmp/testfile.txt'
size:
  description: The size of the text content written to the file in bytes.
  type: int
  returned: always
  sample: 11
'''

from ansible.module_utils.basic import AnsibleModule

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True)
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        path='',
        size=0
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    result['path'] = module.params['path']
    result['size'] = len(module.params['content'].encode('utf-8'))

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    try:
        if not os.path.exists(module.params['path']):
            result['changed'] = True
        else:
            with open(module.params['path'], 'r') as f:
                if f.read() != module.params['content']:
                    result['changed'] = True

        if result['changed']:
            with open(module.params['path'], 'w') as f:
                f.write(module.params['content'])

    except Exception as e:
        module.fail_json(msg=f"Failed to write file: {str(e)}", **result)

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    if module.params['path'] == 'fail me':
        module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()
